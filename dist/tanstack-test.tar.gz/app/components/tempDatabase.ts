export const ModuleRegistry = new Map([["COMP30020", "Third Year Project"]]);
